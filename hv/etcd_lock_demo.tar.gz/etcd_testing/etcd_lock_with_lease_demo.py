from multiprocessing import Pool

from etcd_client import EtcdClient

class LeasedLock(object):
    def __init__(self, names, host="http://127.0.0.1", port=2379, ttl=5, user=""):
        self.names = names
        self.client = EtcdClient(host=host, port=port)
        self.ttl = ttl
        self.lease = None
        self.user = user

    def __enter__(self):
        self.lease = self.client.grant_lease(ttl=self.ttl)
        for name in self.names:
            self.client.lock(name=name, lease=self.lease)
            print("User {} has acquired lock for {}".format(self.user, name))

    def __exit__(self, *args):
        print("User {} is releasing their locks".format(self.user))
        self.client.revoke_lease(self.lease)

def lock(name):
    with LeasedLock(names=["clustera_foo", "dob_bar"], user=name) as _:
        print("User {} is in the lock".format(name))

processes = 8
pool = Pool(processes)
pool.map(lock, list(range(processes)))
