# etcd locking demo
Simple demos to show working examples of locking both with and without leases using etcd.

To run:
1. Install the `requests` library: `pip install requests`
2. Run the demo script: `./run_etcd_lock_demo.sh` (it's important to run it from the directory the files are in)