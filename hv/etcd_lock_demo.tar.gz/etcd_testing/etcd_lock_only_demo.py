import time
from multiprocessing import Pool

from etcd_client import EtcdClient

def lock(name):
    client = EtcdClient()
    lock_target = "testlock"

    lock_key = client.lock(lock_target)
    print("user {} acquired the lock".format(name))
    time.sleep(.1)
    print("user {} releasing the lock".format(name))
    client.unlock(lock_key)

processes = 8
pool = Pool(processes)
pool.map(lock, list(range(processes)))
