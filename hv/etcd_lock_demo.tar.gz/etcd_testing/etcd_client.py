from multiprocessing import Pool
import json
import base64
import sys

import requests

class EtcdClient():
    def __init__(self, host="http://127.0.0.1", port=2379):
        self.host = host
        self.port = port

    def _to_base64(self, s):
        b = s.encode("UTF-8")
        e = base64.b64encode(b)
        if sys.version_info[0] >= 3:
            # bytes objects aren't json serializable in python 3, so we need to convert to a string
            # since python makes a string that looks like "b'dGVzdGxvY2s='"
            # we need to trim the surrounding b and single quotes
            return str(e)[2:-1]
        else:
            return e

    def rpc_call(self, endpoint, payload):
        url = "{host}:{port}/v3beta/{endpoint}".format(
            host=self.host,
            port=self.port,
            endpoint=endpoint
        )

        if not isinstance(payload, str):
            payload = json.dumps(payload)

        res = requests.post(url, payload)


        if res.status_code > 299:
            raise Exception("A {status_code} error was returned by the following call:" \
                            "\nendpoint: {endpoint}\npayload: {payload}\nError: {error}".format(
                                status_code=res.status_code,
                                endpoint=url,
                                payload=payload,
                                error=res.text
                            ))

        return res.json()


    def grant_lease(self, ttl):
        payload = {
            "TTL": ttl
        }

        res = self.rpc_call("lease/grant", payload)

        return res["ID"]

    def revoke_lease(self, id):
        payload = {
            "ID": id
        }

        res = self.rpc_call("kv/lease/revoke", payload)

        return True

    def check_lease(self, id):
        payload = {
            "ID": "string"
        }

        res = self.rpc_call("kv/lease/timetolive", payload)

        return res["TTL"] > 0

    def lock(self, name, lease=None):
        payload = {
            'name': self._to_base64(name),
            'lease': lease
        }

        res = self.rpc_call("lock/lock", payload)

        return res["key"]

    def unlock(self, key):
        payload = {
            'key': key
        }

        res = self.rpc_call("lock/unlock", payload)

        return True